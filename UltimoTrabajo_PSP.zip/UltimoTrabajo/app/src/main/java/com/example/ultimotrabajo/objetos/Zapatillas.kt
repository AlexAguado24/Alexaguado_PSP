package com.example.ultimotrabajo.objetos

data class Zapatillas(var nombre: String, var tipo:String, var imagen:Int):java.io.Serializable