package com.example.ultimotrabajo.objetos

data class Usuario(var nombre: String, var contrasenia:String): java.io.Serializable