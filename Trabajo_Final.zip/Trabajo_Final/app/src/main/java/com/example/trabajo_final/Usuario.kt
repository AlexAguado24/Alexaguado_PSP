package com.example.trabajo_final

data class Usuario(var nombre: String, var contrasenia:String):java.io.Serializable